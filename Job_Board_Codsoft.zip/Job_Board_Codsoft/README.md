# task2_codsoft
I have developed the job board as task 2 of codsoft internship.
